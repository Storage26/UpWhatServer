module.exports = (text) => {
    if (text != undefined)
    {
        if (text != null)
        {
            return text.toString().trim() != ""
        }
        else
        {
            return false
        }
    }
    else
    {
        return false
    }
}