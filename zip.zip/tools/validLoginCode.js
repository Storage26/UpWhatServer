module.exports = (text, len) => {
    if (text.length == len)
    {
        try
        {
            a = parseInt(text)
            return true
        }
        catch
        {
            return false
        }
    }
    else
    {
        return false
    }
}