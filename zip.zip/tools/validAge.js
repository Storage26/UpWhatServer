module.exports = (text) => {
    try
    {
        let a = parseInt(text)

        return (a > 0)
    }
    catch
    {
        return false
    }
}