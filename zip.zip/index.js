/// VARIABLES ///
const http = require("http")
const multer = require("multer")
const {google} = require("googleapis")
const sizeOf = require("image-size")
const app = require("express")()
const server = http.createServer(app)
const admin = require("firebase-admin")
const nodemailer = require("nodemailer")
const body_parser = require("body-parser")
const exist = require("./tools/exist")
const fs = require("fs")
const validEmail = require("./tools/validEmail")
const validAge = require("./tools/validAge")
const validLoginCode = require("./tools/validLoginCode")
const loginCodeLength = 5
const biography_max_length = 200
const display_name_max_length = 50
const user_default_name = "UpWhat User"
const user_default_bio = "Hey there! I am using UpWhat."
const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: "upwhatac@gmail.com",
        pass: "lacfyxawsksliqhp"
    }
})

/// USE CASES ///
app.use(body_parser.urlencoded({extended: true}))
app.use(body_parser.json())

/// MULTER CONFIGURATION ///
const multerStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "temporary_storage/profile_picture")
    },
    filename: (req, file, cb) => {
        let date = Date.now().toString()
        let random_number = (Math.floor(Math.random() * 9000000000) + 1000000000).toString()
        let ext = "." + file.mimetype.split("/")[1]
        let fullName = random_number + date + ext
        file.fullName = fullName
        cb(null, fullName)
    }
})

const multerFilter = (req, file, cb) => {
    if (file.mimetype.split("/")[1] != "png")
    {
        cb(new Error(""), false)
    }
    else
    {
        cb(null, true)
    }
}

const multerUpload = multer({
    storage: multerStorage,
    fileFilter: multerFilter,
    limits: {
        fileSize: 1000000,
        files: 1
    }
})

const multerFinalUpload = multerUpload.single("file")

/// INITIALIZE FIREBASE-ADMIN ///
admin.initializeApp({
    credential: admin.credential.cert("secret/firebase-database-credential.json"),
    databaseURL: "https://database-upwhat-mobile-app-default-rtdb.firebaseio.com"
})
const database = admin.database()

/// REQUESTS ///
// TODO: Change get and post
app.get("/login-email", (req, res) => {
    var email = req.query.email
    var age = req.query.age

    if (exist(email) && exist(age))
    {
        email = email.toString().trim().toLowerCase()
        age = age.toString().trim()


        if (validAge(age))
        {
            if (validEmail(email))
            {
                let code = (Math.floor(Math.random() * 99999) + 10000).toString()
                let timestamp = parseInt(Math.floor(Date.now() / 1000))

                database.ref("LoginCodes/" + email.replace(".", "?")).set({
                    code: code,
                    timestamp: timestamp
                }).then(() => {
                    let options = {
                        from: {
                            name: "UpWhat Team",
                            address: "upwhatac@gmail.com"
                        },
                        to: email,
                        subject: "Approval for UpWhat Login",
                        html: fs.readFileSync("./mail_templates/login_approval.html").toString().replace("$$$CODE$$$", code)
                    }
                    transporter.sendMail(options, (err, _info) => {
                        if (!err)
                        {
                            res.json({
                                shouldProceed: "true"
                            })
                        }
                        else
                        {
                            res.json({
                                shouldProceed: "false",
                                dataType: "text",
                                headerText: "Internal Server Error",
                                bodyText: "It seems that we have encountered an error on our side. Please try again after a while.",
                                actionType: "ok"
                            })
                        }
                    })
                }).catch(() => {
                    res.json({
                        shouldProceed: "false",
                        dataType: "text",
                        headerText: "Internal Server Error",
                        bodyText: "It seems that we have encountered an error on our side. Please try again after a while.",
                        actionType: "ok"
                    })
                })
            }
            else
            {
                res.json({
                    shouldProceed: "false",
                    dataType: "text",
                    headerText: "Invalid Email",
                    bodyText: "The email you entered is invalid. Please enter a valid email to proceed.",
                    actionType: "ok"
                })
            }
        }
        else
        {
            res.json({
                shouldProceed: "false",
                dataType: "text",
                headerText: "Invalid Age",
                bodyText: "Please enter your correct age to confirm that you are allowed to use this application.",
                actionType: "ok"
            })
        }
    }
    else
    {
        res.json({
            shouldProceed: "false",
            dataType: "text",
            headerText: "Invalid Data Received",
            bodyText: "Please make sure your application is up-to-date. If it is, then this may be a server-side problem.",
            actionType: "ok"
        })
    }
})

app.get("/login-code", (req, res) => {
    let timestamp = parseInt(Math.floor(Date.now() / 1000))
    var email = req.query.email
    var code = req.query.code

    if (exist(email) && exist(code))
    {
        email = email.toString().trim().toLowerCase()
        code = code.toString().trim()


        if (validEmail(email))
        {
            if (validLoginCode(code, loginCodeLength))
            {
                database.ref("LoginCodes/" + email.replace(".", "?")).get().then((snap) => {
                    if (snap.hasChild("code") && snap.hasChild("timestamp"))
                    {
                        let actualCode = snap.child("code").val().toString()
                        let actualTimestamp = snap.child("timestamp").val().toString()
    
                        if (timestamp - actualTimestamp < 300)
                        {
                            if (code == actualCode)
                            {
                                database.ref("UserDetail/" + email.replace(".", "?")).get().then(snap1 => {
                                    database.ref("LoginCodes/" + email.replace(".", "?")).remove().then(() => {
                                        let newToken = ""
                                        let characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
                                        let charactersLength = characters.length
            
                                        for (i = 0; i < 50; i++)
                                        {
                                            newToken += characters.charAt(Math.floor(Math.random() * charactersLength)).toString()
                                        }

                                        let user_name = user_default_name;
                                        let user_bio = user_default_bio;

                                        if (snap1.hasChild("displayName"))
                                        {
                                            user_name = snap1.child("displayName").val().toString()
                                        }

                                        if (snap1.hasChild("biography"))
                                        {
                                            user_bio = snap1.child("biography").val().toString()
                                        }

                                        database.ref("UserDetail/" + email.replace(".", "?") + "/loginToken").set(newToken).then(() => {
                                            res.json({
                                                success: true,
                                                token: newToken,
                                                displayName: user_name,
                                                biography: user_bio
                                            })
                                        }).catch(() => {
                                            res.json({
                                                success: false,
                                                dataType: "text",
                                                headerText: "Internal Server Error",
                                                bodyText: "It seems that we have encountered an error on our side. Please try again after a while.",
                                                actionType: "ok"
                                            })
                                        })
                                    }).catch(() => {
                                        res.json({
                                            success: false,
                                            dataType: "text",
                                            headerText: "Internal Server Error",
                                            bodyText: "It seems that we have encountered an error on our side. Please try again after a while.",
                                            actionType: "ok"
                                        })
                                    })
                                }).catch(() => {
                                    res.json({
                                        success: false,
                                        dataType: "text",
                                        headerText: "Internal Server Error",
                                        bodyText: "It seems that we have encountered an error on our side. Please try again after a while.",
                                        actionType: "ok"
                                    })
                                })
                            }
                            else
                            {
                                res.json({
                                    success: false,
                                    dataType: "text",
                                    headerText: "Incorrect Code",
                                    bodyText: "The code you entered is incorrect. Please make sure you have entered the correct login code.",
                                    actionType: "ok"
                                })
                            }
                        }
                        else
                        {
                            res.json({
                                success: false,
                                dataType: "text",
                                headerText: "Code Expired",
                                bodyText: "Your code was valid for only 5 minutes, and has been expired. Please request for a new login code.",
                                actionType: "ok"
                            })
                        }
                    }
                    else
                    {
                        res.json({
                            success: false,
                            dataType: "text",
                            headerText: "Incorrect Code",
                            bodyText: "The code you entered is incorrect, or your code may has been expired. Please note the code becomes invalid after 5 minutes.",
                            actionType: "ok"
                        })
                    }
                }).catch(() => {
                    res.json({
                        success: false,
                        dataType: "text",
                        headerText: "Internal Server Error",
                        bodyText: "It seems that we have encountered an error on our side. Please try again after a while.",
                        actionType: "ok"
                    })
                })
            }
            else
            {
                res.json({
                    success: false,
                    dataType: "text",
                    headerText: "Code Error",
                    bodyText: "The length of login code provided by you isn't " + loginCodeLength + " digit long. Please enter a valid login code to proceed.",
                    actionType: "ok"
                })
            }
        }
        else
        {
            res.json({
                success: false,
                dataType: "text",
                headerText: "Invalid Email",
                bodyText: "The email you entered is invalid. Please enter a valid email to proceed.",
                actionType: "ok"
            })
        }
    }
    else
    {
        res.json({
            success: false,
            dataType: "text",
            headerText: "Invalid Data Received",
            bodyText: "Please make sure your application is up-to-date. If it is, then this may be a server-side problem.",
            actionType: "ok"
        })
    }
})

app.get("/update-display-name", (req, res) => {
    let email = req.query.email
    let token = req.query.token
    let displayName = req.query.display_name

    if (exist(displayName) && exist(token) && exist(email) && validEmail(email))
    {
        email = email.toString().trim().toLowerCase()
        displayName = displayName.toString().trim()

        if (displayName.length <= display_name_max_length)
        {
            database.ref("UserDetail/" + email.replace(".", "?")).get().then(snap => {
                if (snap.hasChild("loginToken"))
                {
                    let actualToken = snap.child("loginToken").val().toString()
    
                    if (token == actualToken)
                    {
                        database.ref("UserDetail/" + email.replace(".", "?") + "/displayName").set(displayName).then(() => {
                            res.json({
                                success: true
                            })
                        }).catch(() => {
                            res.json({
                                success: false,
                                dataType: "text",
                                headerText: "Internal Server Error",
                                bodyText: "It seems that we have encountered an error on our side. Please try again after a while.",
                                actionType: "ok"
                            })
                        })
                    }
                    else
                    {
                        res.json({
                            success: false,
                            dataType: "text",
                            headerText: "Invalid Credentials",
                            bodyText: "It seems that you are logged out of your account. Please re-login.",
                            actionType: "logout_and_done"
                        })
                    }
                }
                else
                {
                    res.json({
                        success: false,
                        dataType: "text",
                        headerText: "Invalid Credentials",
                        bodyText: "It seems that you are logged out of your account. Please re-login.",
                        actionType: "logout_and_done"
                    })
                }
            }).catch(() => {
                res.json({
                    success: false,
                    dataType: "text",
                    headerText: "Internal Server Error",
                    bodyText: "It seems that we have encountered an error on our side. Please try again after a while.",
                    actionType: "ok"
                })
            })
        }
        else
        {
            res.json({
                success: false,
                dataType: "text",
                headerText: "Invalid Name",
                bodyText: "Length of your name cannot be over " + display_name_max_length.toString() + " characters.",
                actionType: "ok"
            })
        }
    }
    else
    {
        res.json({
            success: false,
            dataType: "text",
            headerText: "Invalid Data Received",
            bodyText: "Please make sure your application is up-to-date. If it is, then this may be a server-side problem.",
            actionType: "ok"
        })
    }
})

app.get("/get-basic-user-info", (req, res) => {
    let email = req.query.email
    let token = req.query.token
    let otherEmail = req.query.other_email

    if (exist(email) && exist(token) && exist(otherEmail))
    {
        email = email.toString().trim().toLowerCase()

        database.ref("UserDetail/" + email.replace(".", "?")).get().then(snap => {
            if (snap.hasChild("loginToken"))
            {
                let actualToken = snap.child("loginToken").val().toString()
    
                if (token == actualToken)
                {
                    database.ref("UserDetail/" + otherEmail.replace(".", "?")).get().then(snap => {
                        if (snap.hasChild("displayName"))
                        {
                            let displayName = snap.child("displayName").val().toString()
            
                            res.json({
                                success: true,
                                display_name: displayName
                            })
                        }
                        else
                        {
                            res.json({
                                success: false,
                                dataType: "text",
                                headerText: "Wrong Email",
                                bodyText: "This email address isn't associated with any account. Please make sure you have entered the correct email address.",
                                actionType: "ok"
                            })
                        }
                    }).catch(() => {
                        res.json({
                            success: false,
                            dataType: "text",
                            headerText: "Internal Server Error",
                            bodyText: "It seems that we have encountered an error on our side. Please try again after a while.",
                            actionType: "ok"
                        })
                    })
                }
                else
                {
                    res.json({
                        success: false,
                        dataType: "text",
                        headerText: "Invalid Credentials",
                        bodyText: "It seems that you are logged out of your account. Please re-login.",
                        actionType: "logout_and_done"
                    })
                }
            }
            else
            {
                res.json({
                    success: false,
                    dataType: "text",
                    headerText: "Invalid Credentials",
                    bodyText: "It seems that you are logged out of your account. Please re-login.",
                    actionType: "logout_and_done"
                })
            }
        }).catch(() => {
            res.json({
                success: false,
                dataType: "text",
                headerText: "Internal Server Error",
                bodyText: "It seems that we have encountered an error on our side. Please try again after a while.",
                actionType: "ok"
            })
        })
    }
    else
    {
        res.json({
            success: false,
            dataType: "text",
            headerText: "Invalid Data Received",
            bodyText: "Please make sure your application is up-to-date. If it is, then this may be a server-side problem.",
            actionType: "ok"
        })
    }
})

app.get("/update-biography", (req, res) => {
    let email = req.query.email
    let token = req.query.token
    let biography = req.query.biography

    if (exist(biography) && exist(token) && exist(email) && validEmail(email))
    {
        email = email.toString().trim().toLowerCase()
        biography = biography.toString().trim()

        if (biography.length <= biography_max_length)
        {
            database.ref("UserDetail/" + email.replace(".", "?")).get().then(snap => {
                if (snap.hasChild("loginToken"))
                {
                    let actualToken = snap.child("loginToken").val().toString()
    
                    if (token == actualToken)
                    {
                        database.ref("UserDetail/" + email.replace(".", "?") + "/biography").set(biography).then(() => {
                            res.json({
                                success: true
                            })
                        }).catch(() => {
                            res.json({
                                success: false,
                                dataType: "text",
                                headerText: "Internal Server Error",
                                bodyText: "It seems that we have encountered an error on our side. Please try again after a while.",
                                actionType: "ok"
                            })
                        })
                    }
                    else
                    {
                        res.json({
                            success: false,
                            dataType: "text",
                            headerText: "Invalid Credentials",
                            bodyText: "It seems that you are logged out of your account. Please re-login.",
                            actionType: "logout_and_done"
                        })
                    }
                }
                else
                {
                    res.json({
                        success: false,
                        dataType: "text",
                        headerText: "Invalid Credentials",
                        bodyText: "It seems that you are logged out of your account. Please re-login.",
                        actionType: "logout_and_done"
                    })
                }
            }).catch(() => {
                res.json({
                    success: false,
                    dataType: "text",
                    headerText: "Internal Server Error",
                    bodyText: "It seems that we have encountered an error on our side. Please try again after a while.",
                    actionType: "ok"
                })
            })
        }
        else
        {
            res.json({
                success: false,
                dataType: "text",
                headerText: "Invalid Biography",
                bodyText: "Length of your biography cannot be over " + biography_max_length.toString() + " characters.",
                actionType: "ok"
            })
        }
    }
    else
    {
        res.json({
            success: false,
            dataType: "text",
            headerText: "Invalid Data Received",
            bodyText: "Please make sure your application is up-to-date. If it is, then this may be a server-side problem.",
            actionType: "ok"
        })
    }
})

// app.post("/set-profile-picture", (req, res) => {
//     multerFinalUpload(req, res, err => {
//         if (!err)
//         {
//             let fullPath = "temporary_storage/profile_picture/" + req.file.fullName

//             // Check picture ratio
//             if (sizeOf(fullPath).width === sizeOf(fullPath).height)
//             {
//                 setTimeout(() => {
//                     res.download(fullPath)
//                 }, 10000)
//             }
//             else
//             {
//                 fs.unlink(fullPath, () => {})

//                 res.json({
//                     success: false,
//                     dataType: "text",
//                     headerText: "Image Not Cropped",
//                     bodyText: "Please make sure you have cropped the image to 1:1 size.",
//                     actionType: "ok"
//                 })
//             }
//         }
//         else
//         {
//             res.json({
//                 success: false,
//                 dataType: "code",
//                 code: "ERROR"
//             })
//         }
//     })
// })

app.get("*", (_req, res) => {
    res.json({
        shouldProceed: "false",
        dataType: "text",
        headerText: "Application Downdated",
        bodyText: "It seems that the current version is not suitable of sending requests to the server the correct way. Please update your application to it's latest version.",
        actionType: "ok"
    })
})

app.post("*", (_req, res) => {
    res.json({
        shouldProceed: "false",
        dataType: "text",
        headerText: "Application Downdated",
        bodyText: "It seems that the current version is not suitable of sending requests to the server the correct way. Please update your application to it's latest version.",
        actionType: "ok"
    })
})

/// START SERVER ///
app.listen(process.env.PORT || 8000, () => {
    /// TODO: REMOVE ///
    console.log("Started.")
})